package AbstractClasses;

public interface CanFly {
    void fly();
}
