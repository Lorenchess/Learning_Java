package AreaCalculator;

public class Main {
    public static void main(String[] args) {
        AreaCalculator.area(5.0);
        AreaCalculator.area(-1);
        AreaCalculator.area(5.0, 4.0);
        AreaCalculator.area(-1.0, 4.0);
    }
}
