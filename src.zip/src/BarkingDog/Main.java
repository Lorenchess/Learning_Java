package BarkingDog;

public class Main {
    public static void main(String[] args) {
        BarkingDog.shouldWakeUp(true,10);
        BarkingDog.shouldWakeUp(true,-10);
        BarkingDog.shouldWakeUp(true,1);
    }
}
