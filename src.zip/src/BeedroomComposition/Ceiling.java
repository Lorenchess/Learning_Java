package BeedroomComposition;

public class Ceiling {
    private String color;

    public Ceiling(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
}
