package CarDealership;

public class Vehicle {

}
