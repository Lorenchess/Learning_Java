package Classes;

public class Main {
    public static void main(String[] args) {
       Car ferrary = new Car(4,4,"Fire","Turbo","Red");
       Car lamborgini = new Car(2,4,"McLoren","Turbo","Blue");

        System.out.println("Model is " + ferrary.getModel());
    }
}
