package Collections;

public class Seat {
}
