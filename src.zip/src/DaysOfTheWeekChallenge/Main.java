package DaysOfTheWeekChallenge;

public class Main {
    public static void main(String[] args) {
        DaysOfTheWeek.printDaysOfTheWeek(5);
    }
}
