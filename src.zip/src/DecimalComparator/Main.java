package DecimalComparator;

public class Main {
    public static void main(String[] args) {
        DecimalComparator.areEqualByThreeDecimalPlaces(3.1755,3.1755);
        DecimalComparator.areEqualByThreeDecimalPlaces(3.1705,3.1755);
    }
}
