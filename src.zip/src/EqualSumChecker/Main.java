package EqualSumChecker;

public class Main {
    public static void main(String[] args) {
        EqualSumChecker.hasEqualSum(1,2,3);
    }
}
