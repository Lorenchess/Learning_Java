package FeetAndInchesToCentimeters;

public class Main {
    public static void main(String[] args) {
        FeetAndInchesToCentimeters.printFeetAndInchesToCentimeters(5,5);
    }
}
