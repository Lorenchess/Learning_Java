package Generics;

public class FootballPlayer extends Player{
    public FootballPlayer(String name) {
        super(name);
    }
}
