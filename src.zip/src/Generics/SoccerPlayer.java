package Generics;

public class SoccerPlayer extends Player{
    public SoccerPlayer(String name) {
        super(name);
    }
}
