package IntroToPackages;

public class Main {
    public static void main(String[] args) {
      MyWindow myWindow = new MyWindow("Complete Java");
      myWindow.setVisible(true);
    }
}
