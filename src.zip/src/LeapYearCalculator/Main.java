package LeapYearCalculator;

public class Main {
    public static void main(String[] args) {
        LeapYearCalculator.isLeapYear(1600);
        LeapYearCalculator.isLeapYear(2021);
        LeapYearCalculator.isLeapYear(2000);
        LeapYearCalculator.isLeapYear(1924);
    }
}
