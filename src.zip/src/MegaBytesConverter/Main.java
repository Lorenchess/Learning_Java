package MegaBytesConverter;

public class Main {
    public static void main(String[] args) {
        MegaBytesConverter.printMegaBytesAndKiloBytes(-5000);
        MegaBytesConverter.printMegaBytesAndKiloBytes(5000);
    }
}
