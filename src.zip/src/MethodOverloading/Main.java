package MethodOverloading;

public class Main {
    public static void main(String[] args) {
        MethodOverloading.myOverloadMethod(2,3);
        MethodOverloading.myOverloadMethod(2,3,7);
        MethodOverloading.myOverloadMethod(2, 3, 7, 2);
    }
}
