package MinutesToYearsAndDaysCalculator;

public class Main {
    public static void main(String[] args) {
        MinutesToYearsAndDaysCalculator.printYearsAndDays(561600);
    }
}
