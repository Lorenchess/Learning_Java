package NumberInWord;

public class Main {
    public static void main(String[] args) {
        NumberInWord.printNumberInWord(7);
        NumberInWord.printNumberInWord(-7);
    }
}
