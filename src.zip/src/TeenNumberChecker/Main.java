package TeenNumberChecker;

public class Main {
    public static void main(String[] args) {
        TeenNumberChecker.hasTeen(10,4,3);
        TeenNumberChecker.hasTeen(13,4,3);
    }
}
