package speedConverter;

public class Main {
    public static void main(String[] args) {
       //we are able to call mte methods from SpeedConverter class using the dot operator.
       SpeedConverter.printConversion(10);
    }
}
